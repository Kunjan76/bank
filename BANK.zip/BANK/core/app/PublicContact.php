<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PublicContact extends Model
{
    protected $guarded = ['id'];
}
